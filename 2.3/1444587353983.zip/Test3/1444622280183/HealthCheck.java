
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.ec2.AmazonEC2Client;
import com.amazonaws.services.ec2.model.Instance;



public class HealthCheck implements Runnable {
	private final LoadBalancer loadBalancer;
	private final String address;	
	private final int number;
	HttpURLConnection connection = null;
	URL checkUrl = null;

	BasicAWSCredentials bawsc = new BasicAWSCredentials("AKIAJ3AED3E6NDMANTGQ",
			"pnJGBB/w2qIZk1onOQFXR7/pqiGzBETfQBQ4Mm7b");	// Submission password has been deleted.
	AmazonEC2Client ec2 = new AmazonEC2Client(bawsc);	

	public HealthCheck(LoadBalancer loadBalancer, String address, int number) {
		this.loadBalancer = loadBalancer;
		this.address = address;
		this.number = number;
	}
	
	// Connect the data center lookup/random url.
	public void connect(String address) throws Exception{
		checkUrl = new URL(address);		
		connection = (HttpURLConnection)checkUrl.openConnection();
		connection.setConnectTimeout(1000);
		connection.setReadTimeout(1000);
	}
	
	@Override
	public void run() {
		System.out.println("intorun");
		try {
			go();
		} catch (Exception e) {
			e.printStackTrace();
		}	
	}
	
	public void go() throws Exception {		
		System.out.println("intogo");
		boolean isConnect = false;
		while (!isConnect) {			
			try {
				connect(address);
				isConnect = true;
			} catch (Exception e) {
				
			}
		}
		// Check the response
		while (true) {			
			try {
				if (connection.getResponseCode() != 200) {
					System.out.println("kill!!!!!!!!!!!!!!!!!!!!!");
					loadBalancer.setRunning(number, 0);
					addNewInstance();
					System.out.println("addNewInstance()");
				}
			} catch (IOException e) {
				System.out.println("kill!!!!!!!!!!!!!!!!!!!!!");
				loadBalancer.setRunning(number, 0);
				addNewInstance();
			}	
			Thread.sleep(1000);
		}
	}
	
public synchronized void addNewInstance() {
		
		System.out.println("inside addNewInstance()");
		Instance newDataCenter = Launching.lauchInstance(ec2,
				 "ami-ed80c388", 
				 "m3.medium", 
				 1, 
				 1, 
				 "ccProject", 
				 "alltraffic");	
		System.out.println("inside addNewInstance() 2");

		boolean isRun = false;
		while (isRun == false) {			
		isRun = IsRunning.isRunning(newDataCenter.getInstanceId(), ec2);			
		}		
		String Dns = GetInstancePublicDnsName.getInstancePublicDnsName(newDataCenter.getInstanceId() , ec2);	
		
		System.out.println("inside addNewInstance() 3");

		boolean isConnect = false;
		while (!isConnect) {			
			try {
				connect("http://" + Dns + "/lookup/random");
				isConnect = true;
			} catch (Exception e) {
				
			}
		}			
		System.out.println("inside addNewInstance() 4");
		DataCenterInstance instance = new DataCenterInstance("new_instance", "http://" + Dns, number);
		loadBalancer.setInstance(instance, number);
		loadBalancer.setRunning(number, 1);
	}

}
